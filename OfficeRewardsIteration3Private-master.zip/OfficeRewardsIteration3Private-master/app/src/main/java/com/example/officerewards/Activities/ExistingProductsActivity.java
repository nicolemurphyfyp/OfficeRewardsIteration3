package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.officerewards.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import adapter.ExistingProductsRecyclerAdapter;
import adapter.ProductRecyclerAdapter;
import model.Product;

public class ExistingProductsActivity extends AppCompatActivity {

    //recycler code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    // Recycler View object
    RecyclerView recyclerView;
    // Layout Manager
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    RecyclerView.Adapter adapter;
    // Linear Layout Manager
    LinearLayoutManager LayoutManager;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_existing_products);

        List<Product> productList = new ArrayList<Product>();

        //get the list of all products
        //place them into a list of product objects
        //then pass that list to the recycler
        db.collection("Products")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String name = (String) document.getData().get("Name");
                                String price = (String) document.getData().get("Cost");
                                String id = (String) document.getId();
                                String category = (String) document.getData().get("Category");
                                Product product = new Product(name, category, price, id);
                                Log.d("CHECK1", product.getName());
                                productList.add(product);
                            }
                            adapter = new ExistingProductsRecyclerAdapter(productList, ExistingProductsActivity.this);
                            LayoutManager = new LinearLayoutManager(ExistingProductsActivity.this,LinearLayoutManager.VERTICAL,false);
                            recyclerView = findViewById(R.id.rvExistingProducts);
                            recyclerView.setLayoutManager(LayoutManager);
                            recyclerView.setAdapter(adapter);

                        } else {
                            Toast.makeText(ExistingProductsActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}