package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officerewards.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import adapter.BasketItemRecyclerAdapter;
import adapter.ExistingProductsRecyclerAdapter;
import model.OrderItem;
import model.Product;

public class BasketActivity extends AppCompatActivity {


    //declare firebase objects, on screen components and recycler components
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    String userID, points, currentDate;
    FirebaseAuth auth;
    TextView txtTotalPrice, txtCurrentBalance, txtNewBalance;
    Button btnBackToShop, btnEmptyBasket, btnPlaceOrder;
    List<OrderItem> orderItemList, orderItems;
    List<Integer> priceList;
    List<String> cartList;
    int counter, counter2, totalprice;

    // Recycler View object
    RecyclerView recyclerView;

    // Layout Manager
    RecyclerView.LayoutManager RecyclerViewLayoutManager;

    RecyclerView.Adapter adapter;

    // Linear Layout Manager
    LinearLayoutManager LayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket);

        //get the current date, adapted from https://stackoverflow.com/a/15698784
        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        //assign objects
        auth = FirebaseAuth.getInstance();
        userID = auth.getCurrentUser().getUid();
        txtTotalPrice = findViewById(R.id.txtTotalPrice);
        txtCurrentBalance = findViewById(R.id.txtCurrentBalance);
        txtNewBalance = findViewById(R.id.txtBalanceAfterOrder);
        btnBackToShop = findViewById(R.id.btnBackToShop);
        btnEmptyBasket = findViewById(R.id.btnEmptyBasket);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        //call method which is the first step in populating the recycler
        retrieveData();
    }

    //STEP 1 in populating recycler
    //first this method gets the points balance of the current user, using their ID
    public void retrieveData() {
        //Retrieving the points for the current user

        List<Integer> priceList = new ArrayList<Integer>();

        //https://firebase.google.com/docs/firestore/query-data/get-data
        DocumentReference documentReference = db.collection("Points").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        points = String.valueOf(document.getData().get("points"));
                        txtCurrentBalance.setText("Current Balance: " + points + " Points");

                        //Retrieving Total Price from Basket
                        db.collection("Baskets").document(userID).collection("cartItems")
                                .get()
                                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        Log.d("BUTTONCHECK", "onComplete");
                                        if (task.isSuccessful()) {
                                            Log.d("BUTTONCHECK", "task successful");
                                            if(task.getResult().isEmpty()) {
                                                //if there is nothing in the basket, disable the place order button and alert the user using the textview
                                                //adapted from https://stackoverflow.com/a/4384994
                                                Log.d("BUTTONCHECK", "HERE?");
                                                btnPlaceOrder.setEnabled(false);
                                                txtTotalPrice.setText("");
                                                txtNewBalance.setText("Nothing in Basket!");
                                            }
                                            else {
                                                //if there is something, loop through each items in the basket, and sum the total price
                                                for (QueryDocumentSnapshot document : task.getResult()) {
                                                    Log.d("BUTTONCHECK", "for each");
                                                    if (document.exists()) {
                                                        Log.d("BUTTONCHECK", "EXISTS");
                                                        int price = Integer.parseInt((String) document.getData().get("Cost"));
                                                        priceList.add(price);
                                                        //if the two lists are equal in size, then the for loop is complete
                                                        if (priceList.size() == task.getResult().size()) {
                                                            totalprice = sum(priceList);
                                                            txtTotalPrice.setText("Total Price: " + totalprice + " Points");

                                                            //Show the user what their balance would be after placing the purchase, if they dont have enough
                                                            //then we tell them on the textview and disable the place order button
                                                            if (Integer.parseInt(points) - totalprice >= 0) {
                                                                txtNewBalance.setText("Balance After Placing Order: " + String.valueOf(Integer.parseInt(points) - totalprice));
                                                            }
                                                            else {
                                                                btnPlaceOrder.setEnabled(false);
                                                                txtNewBalance.setText("Not Enough Points!");
                                                            }
                                                        }
                                                    }
                                                }
                                                //calling the method which is step 2 in displaying the recycler view
                                                setupRecycler();
                                            }
                                        } else {
                                            Toast.makeText(BasketActivity.this, "Error - " + task.getException(), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d("TAG", e.toString());
                                    }
                                });
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });
    }

    //STEP 2
    //loop through each item in the user's basket on firebase, and place them into a list
    //then pass the list to the recycler and display it
    public void setupRecycler() {
        List<OrderItem> orderItems = new ArrayList<OrderItem>();

        db.collection("Baskets").document(userID).collection("cartItems")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String name = (String) document.getData().get("ProductName");
                                String price = (String) document.getData().get("Cost");
                                String id = (String) document.getData().get("ProductID");
                                int quantity = Integer.parseInt(String.valueOf(document.getData().get("Quantity")));
                                OrderItem orderItem = new OrderItem(name, "xyz", price, id, quantity);
                                orderItems.add(orderItem);
                                //if the two lists are equal in size, then the for loop is complete
                                if (orderItems.size() == task.getResult().size()) {
                                    //recycler set up code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
                                    adapter = new BasketItemRecyclerAdapter(orderItems, BasketActivity.this);
                                    LayoutManager = new LinearLayoutManager(BasketActivity.this,LinearLayoutManager.VERTICAL,false);
                                    recyclerView = findViewById(R.id.rvBasket);
                                    recyclerView.setLayoutManager(LayoutManager);
                                    recyclerView.setAdapter(adapter);
                                }
                            }
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(BasketActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                    }
                });
    }


    //Returning to the shop activity
    public void backToShop(View view) {
        Intent intent = new Intent(BasketActivity.this,ShopActivity.class);
        startActivity(intent);
    }

    //To empty the basket, we loop through each item in the cartitems subcollection for the current user id
    //then we call the deleteBasket method, passing in the list of item IDs we looped through
    public void emptyBasket(View view) {
        List<String> cartList = new ArrayList<String>();
            db.collection("Baskets").document(userID).collection("cartItems")
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            if (queryDocumentSnapshots.isEmpty()) {
                                Toast.makeText(BasketActivity.this, "Basket Already Empty", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    Log.d("CHECK2", document.getId());
                                    cartList.add(document.getId());
                                }
                                //if the two lists are equal in size, then the for loop is complete
                                if (cartList.size() == queryDocumentSnapshots.size()) {
                                    deleteBasket(cartList, "Button");
                                }
                            }
                            }

                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(BasketActivity.this, "Error - " + e, Toast.LENGTH_SHORT).show();
                        }
                    });
    }

    //this can be called by either the using emptying their basket, or it can be called when the user successfully places an order
    //and we then want to empty the contents of the basket
    //it loops through each item id for the items in the cartitems subcollection on firebase firestore
    //depending on whether the button or the placing order process calls it, a different message is displayed to the user
    //either way the user is sent back to the shop activity
    public void deleteBasket(List<String> list, String caller) {
        counter = 0;
        for (String s: list)
            db.collection("Baskets").document(userID).collection("cartItems").document(s)
                    .delete()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            counter ++;
                            //if the counter and the list are equal in size, then the for loop is complete
                            if (counter == list.size()) {
                                if (caller == "Button") {
                                    Toast.makeText(BasketActivity.this, "Basket Emptied!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(BasketActivity.this,ShopActivity.class);
                                    startActivity(intent);
                                }
                                else {
                                    Toast.makeText(BasketActivity.this, "Order Placed!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(BasketActivity.this,ShopActivity.class);
                                    startActivity(intent);
                                }

                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(BasketActivity.this, "Error Emptying Basket", Toast.LENGTH_SHORT).show();
                        }
                    });
    }

    //step 1 in placing an order
    //check if they have enough points
    //check if they have placed an order today (if they have, they are not allowed to place another)
    //then call the getCartItems method
    public void placeOrder(View view) {
        if (Integer.parseInt(points) - totalprice >= 0) {

            db.collection("Orders").document(userID + currentDate).collection("orderItems")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if(task.isSuccessful()) {
                                QuerySnapshot document = task.getResult();
                                if (document.isEmpty()) {
                                    getCartItems();
                                }
                                else {
                                    Toast.makeText(BasketActivity.this, "Order already placed today, please wait until tomorrow.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });

        }
        else {
            Toast.makeText(this, "Not Enough Points!", Toast.LENGTH_SHORT).show();
        }
    }

    //get each item in the basket, and put them into a list of orderitems
    //pass that list to the method updatePoints
    public void getCartItems() {
        List<OrderItem> orderItemList = new ArrayList<OrderItem>();

        db.collection("Baskets").document(userID).collection("cartItems")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String name = (String) document.getData().get("ProductName");
                                String price = (String) document.getData().get("Cost");
                                String id = (String) document.getData().get("ProductID");
                                String category = (String) document.getData().get("Category");
                                int quantity = Integer.parseInt(String.valueOf(document.getData().get("Quantity")));
                                OrderItem orderItem = new OrderItem(name, category, price, id, quantity);
                                orderItemList.add(orderItem);
                                //if the two lists are equal in size, then the for loop is complete
                                if (orderItemList.size() == task.getResult().size()) {
                                    updatePoints(orderItemList);
                                }
                            }
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(BasketActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //minus the total cost of the order from the user's points balance, update the record on firebase firestore
    //then call the updateOrderRecord method
    public void updatePoints(List<OrderItem> list) {
        db.collection("Points").document(userID)
                .update("points", String.valueOf(Integer.parseInt(points) - totalprice))
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        updateOrderRecord(list);
                    }
                });
    }

    //Place a timestamp under the order record to allow for sorting by when the order was placed
    //then insert a record using a combination of the userID and the current date as the orderid
    //loop through each item in the list passed to this method, and add them to the orderItems subcollection for this newly created order record
    //when they have all been inserted, call emptyBasketAfterOrder
    public void updateOrderRecord(List<OrderItem> list) {

        Map<String, Object> data = new HashMap<>();
        //Using a timestamp allows for sorting orders
        //Adapted from https://medium.com/firebase-developers/the-secrets-of-firestore-fieldvalue-servertimestamp-revealed-29dd7a38a82b
        data.put("timestamp", FieldValue.serverTimestamp());

        db.collection("Orders").document(userID + currentDate)
                .set(data)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            for (OrderItem orderitem : list) {

                                db.collection("Orders").document(userID + currentDate).collection("orderItems")
                                        .add(orderitem)
                                        .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                                if (task.isSuccessful()) {
                                                    counter2++;
                                                    if(counter2 == list.size()) {
                                                        emptyBasketAfterOrder();
                                                    }
                                                }
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(BasketActivity.this, "Error - " + e, Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            }
                        }
                    }
                });
    }

    //loops through each item that was in the users basket and gets the product ID of each one
    //puts them into a list and then call the deleteBasket method
    public void emptyBasketAfterOrder() {
        List<String> cartList = new ArrayList<String>();
        db.collection("Baskets").document(userID).collection("cartItems")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            Log.d("CHECK2", document.getId());
                            cartList.add(document.getId());
                        }
                        //if the two lists are equal in size, then the for loop is complete
                        if (cartList.size() == queryDocumentSnapshots.size()) {
                            deleteBasket(cartList, "OrderPlace");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(BasketActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //summing up items in an integer list, adapted from https://stackoverflow.com/a/5963867
    public int sum(List<Integer> list) {
        int sum = 0;

        for (int i : list)
            sum = sum + i;

        return sum;
    }
}
