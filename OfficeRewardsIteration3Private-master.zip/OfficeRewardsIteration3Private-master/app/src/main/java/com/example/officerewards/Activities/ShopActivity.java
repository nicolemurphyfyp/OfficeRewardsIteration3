package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.officerewards.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import adapter.ProductRecyclerAdapter;
import model.Product;

public class ShopActivity extends AppCompatActivity {

    //recycler code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    // Recycler View object
    RecyclerView recyclerView;
    RecyclerView healthRecyclerView;
    // Layout Manager
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    RecyclerView.Adapter adapter;
    // Linear Layout Manager
    LinearLayoutManager HorizontalLayout;
    Button btnShowBasket;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);
        btnShowBasket = findViewById(R.id.btnShowBasket);

        //setting up the 2 recyclers, for the 2 current categories of items
        setUpRecyclerGeneral();
        setUpRecyclerHealth();

        btnShowBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShopActivity.this,BasketActivity.class);
                startActivity(intent);
            }
        });


        // Bottom Nav Code adapted from https://www.geeksforgeeks.org/how-to-implement-bottom-navigation-with-activities-in-android/
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.page_3);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.page_1:
                        startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.page_2:
                        startActivity(new Intent(getApplicationContext(),MapsActivityCurrentPlace.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.page_3:
                        return true;
                }
                return false;
            }
        });

    }
    //get each product with a category of general, place them into a list and show them on the first recycler
    public void setUpRecyclerGeneral() {
        List<Product> productList = new ArrayList<Product>();

        db.collection("Products")
                .whereEqualTo("Category", "General")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String name = (String) document.getData().get("Name");
                                String price = (String) document.getData().get("Cost");
                                String id = (String) document.getId();
                                String category = (String) document.getData().get("Category");
                                Product product = new Product(name, category, price, id);
                                Log.d("CHECK1", product.getName());
                                productList.add(product);
                            }
                            adapter = new ProductRecyclerAdapter(productList, ShopActivity.this);
                            HorizontalLayout = new LinearLayoutManager(ShopActivity.this,LinearLayoutManager.HORIZONTAL,false);
                            recyclerView = findViewById(R.id.rvShop);
                            recyclerView.setLayoutManager(HorizontalLayout);
                            recyclerView.setAdapter(adapter);

                        } else {
                            Toast.makeText(ShopActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    //get each product with a category of health, place them into a list and show them on the second recycler
    public void setUpRecyclerHealth() {
        List<Product> productList = new ArrayList<Product>();

        db.collection("Products")
                .whereEqualTo("Category", "Health")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String name = (String) document.getData().get("Name");
                                String price = (String) document.getData().get("Cost");
                                String id = (String) document.getId();
                                String category = (String) document.getData().get("Category");
                                Product product = new Product(name, category, price, id);
                                Log.d("CHECK1", product.getName());
                                productList.add(product);
                            }
                            adapter = new ProductRecyclerAdapter(productList, ShopActivity.this);
                            HorizontalLayout = new LinearLayoutManager(ShopActivity.this,LinearLayoutManager.HORIZONTAL,false);
                            healthRecyclerView = findViewById(R.id.rvShopHealth);
                            healthRecyclerView.setLayoutManager(HorizontalLayout);
                            healthRecyclerView.setAdapter(adapter);

                        } else {
                            Toast.makeText(ShopActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}