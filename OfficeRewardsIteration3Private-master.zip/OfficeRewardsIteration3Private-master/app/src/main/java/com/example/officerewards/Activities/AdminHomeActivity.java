package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officerewards.R;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class AdminHomeActivity extends AppCompatActivity {

    //Declare screen components and firebase objects
    TextView txtWelcome;
    FirebaseAuth auth;
    FirebaseFirestore fStore;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        //assign firebase objects and the textview
        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        txtWelcome = findViewById(R.id.txtWelcomeAdmin);

        //Get the name and points balance of the user logged in
        //we get the ID of the currently logged in user which allows us to get the specific document for their name on firebase firestore
        if(auth.getCurrentUser() != null) {
            userID = auth.getCurrentUser().getUid();
            //get the record for the user on firebase
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        txtWelcome.setText("Welcome " + String.valueOf(document.getData().get("Name")));
                    }
                    else {
                        Toast.makeText(AdminHomeActivity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    public void goToAddProduct(View view) {
        //open add product activity
        Intent intent = new Intent(AdminHomeActivity.this,AddProductActivity.class);
        startActivity(intent);
    }

    public void viewProducts(View view) {
        //open view products activity
        Intent intent = new Intent(AdminHomeActivity.this,ExistingProductsActivity.class);
        startActivity(intent);
    }

    //Signs out the user and brings them back to the starting activity, adapted from https://firebase.google.com/docs/auth/android/firebaseui
    public void logOutAdmin(View view) {
        AuthUI.getInstance()
                .signOut(AdminHomeActivity.this)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<Void> task) {
                        Intent intent = new Intent(AdminHomeActivity.this,RegisterActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Toast.makeText(AdminHomeActivity.this, "Sign Out Failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}