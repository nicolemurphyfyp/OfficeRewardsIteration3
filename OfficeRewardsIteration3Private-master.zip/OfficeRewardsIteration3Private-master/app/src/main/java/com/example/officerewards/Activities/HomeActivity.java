package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officerewards.R;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import adapter.BasketItemRecyclerAdapter;
import adapter.OrderListRecyclerAdapter;
import model.Order;
import model.OrderItem;

public class HomeActivity extends AppCompatActivity {

    //declare on screen components and recycler components
    //recycler code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    TextView txtWelcome, txtPointsBal;
    FirebaseAuth auth;
    FirebaseFirestore fStore;
    String userID, name;
    // Recycler View object
    RecyclerView recyclerView;
    // Layout Manager
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    RecyclerView.Adapter adapter;
    // Linear Layout Manager
    LinearLayoutManager LayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //assign firebase objects to access firebase auth and firebase firestore
        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        //assign textviews so we can manipulate them
        txtWelcome = findViewById(R.id.txtWelcome);
        txtPointsBal = findViewById(R.id.txtPointsBal);

        //Get the name and points balance of the user logged in
        if(auth.getCurrentUser() != null) {
            userID = auth.getCurrentUser().getUid();
            //get the record for the user on firebase
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        name = String.valueOf(document.getData().get("Name"));
                        txtWelcome.setText("Welcome " + name);

                        //Retrieving the points for the current user
                        //https://firebase.google.com/docs/firestore/query-data/get-data
                        DocumentReference documentReference = fStore.collection("Points").document(userID);
                        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {
                                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                        String points = String.valueOf(document.getData().get("points"));
                                        txtPointsBal.setText("Points Balance: " + points);
                                        Log.d("TAG", "points: " + points);
                                    } else {
                                        Log.d("TAG", "No such document");
                                    }
                                } else {
                                    Log.d("TAG", "get failed with ", task.getException());
                                }
                            }
                        });
                    }
                    else {
                        Toast.makeText(HomeActivity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }


     // Bottom Nav Code adapted from https://www.geeksforgeeks.org/how-to-implement-bottom-navigation-with-activities-in-android/
    BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
    bottomNavigationView.setSelectedItemId(R.id.page_1);

    bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch(item.getItemId())
    {
        case R.id.page_1:
            //Do nothing as we are already on this page
    return true;
        case R.id.page_2:
            startActivity(new Intent(getApplicationContext(),MapsActivityCurrentPlace.class));
            overridePendingTransition(0,0);
    return true;
        case R.id.page_3:
    startActivity(new Intent(getApplicationContext(),ShopActivity.class));
    overridePendingTransition(0,0);
    return true;
    }
            return false;
        }
    });

    Log.d("ORDERLIST", "set up recycler");
    setupRecycler();

    }
    //Signs out the user and brings them back to the starting activity, adapted from https://firebase.google.com/docs/auth/android/firebaseui
    public void logOut(View view) {
        AuthUI.getInstance()
                .signOut(HomeActivity.this)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<Void> task) {
                        Intent intent = new Intent(HomeActivity.this,RegisterActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Toast.makeText(HomeActivity.this, "Sign Out Failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //STEP 1 of setting up recycler of placed orders
    //loop through each order on firestore, and place each order id into a list of strings
    //we do this as we cannot do a query on firestore for orders which have an id containing the user's ID
    //so we do this instead and will match the order IDs to the user ID in the next step, in the method findOrderIDs
    public void setupRecycler() {
        Log.d("ORDERLIST", "inside set up recycler");
        List<String> idList = new ArrayList<String>();

        fStore.collection("Orders")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            Log.d("ORDERLIST", "task successful");
                            Log.d("ORDERLIST", String.valueOf(task.getResult().getDocuments()));
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("ORDERLIST", "for each doc");
                                idList.add(document.getId());

                                if (idList.size() == task.getResult().size()) {
                                    Log.d("ORDERLIST", String.valueOf(idList.size()));
                                    findOrderIDs(idList);
                                }
                            }
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(HomeActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //for each order id in the string list, we check if they contain the current user's ID.
    //if they do, we add it to a new list called idList
    //we then loop through each ID in idList and retrieve the orderitems from firestore
    //this allows us to get the total price of each order
    //we also get each order date so we can sort them in the list on the recycler
    public void findOrderIDs(List<String> list) {
        List<Order> orderList = new ArrayList<Order>();
        List<String> idList = new ArrayList<String>();

        for (String s : list) {
            if (s.contains(userID)) {
                idList.add(s);
            }
        }

        Log.d("ORDERLIST", "findorderids " + String.valueOf(idList.size()));
        for (String s1: idList) {
            List<Integer> priceList = new ArrayList<Integer>();
            fStore.collection("Orders").document(s1).collection("orderItems")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                Log.d("ORDERLIST", "current id: " + s1);
                                for (DocumentSnapshot document :  task.getResult().getDocuments()) {
                                    Log.d("ORDERLIST", "getting documents");
                                    int cost = Integer.parseInt(String.valueOf(document.get("price")));
                                    Log.d("ORDERLIST", "cost: " + String.valueOf(document.get("price")));
                                    priceList.add(cost);
                                    Log.d("ORDERLIST", "price list size v task size " + priceList.size() + "  " + task.getResult().getDocuments().size() );
                                }

                                if (priceList.size() == task.getResult().getDocuments().size()) {
                                    Log.d("ORDERLIST", "pricelist size  " + priceList.size() + " " + s1);
                                    Log.d("ORDERLIST", "total price calc");
                                    int totalprice = sum(priceList);
                                    Log.d("ORDERLIST", totalprice + "");
                                    String orderdate = "Date: " + s1.substring(s1.length() - 10);

                                    Order order = new Order(s1, orderdate, String.valueOf(totalprice));
                                    orderList.add(order);

                                    Log.d("ORDERLIST", "order size " + orderList.size());
                                    Log.d("ORDERLIST", "id size " + idList.size());

                                    if (orderList.size() == idList.size()) {
                                        Log.d("ORDERLIST", "final steps");
                                        //sort orders by date, adapted from https://www.baeldung.com/java-sort-list-by-date
                                        Collections.sort(orderList);
                                        adapter = new OrderListRecyclerAdapter(orderList, HomeActivity.this);
                                        LayoutManager = new LinearLayoutManager(HomeActivity.this,LinearLayoutManager.VERTICAL,false);
                                        recyclerView = findViewById(R.id.rvOrders);
                                        recyclerView.setLayoutManager(LayoutManager);
                                        recyclerView.setAdapter(adapter);
                                    }
                                }
                            }
                        }
                    });
        }
    }

    //summing up a list of integers, adapted from https://stackoverflow.com/a/5963867
    public int sum(List<Integer> list) {
        int sum = 0;

        for (int i : list)
            sum = sum + i;

        return sum;
    }
}