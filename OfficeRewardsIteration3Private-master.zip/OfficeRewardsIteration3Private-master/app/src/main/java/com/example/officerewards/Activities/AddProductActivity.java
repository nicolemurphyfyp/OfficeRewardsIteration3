package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.officerewards.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddProductActivity extends AppCompatActivity {

    //Declare screen components
    Button btnAdd, btnCancel;
    EditText etName, etCost;
    Spinner spCategory;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        //Assign screen components
        btnAdd = findViewById(R.id.btnAddProduct);
        btnCancel = findViewById(R.id.btnCancelAddProduct);
        etName = findViewById(R.id.etProductName);
        etCost = findViewById(R.id.etProductPrice);
        spCategory = findViewById(R.id.spProductCategory);
    }

    public void cancelAdd(View view) {
        //Cancel any action and return to the admin home activity instead
        Intent intent = new Intent(AddProductActivity.this,AdminHomeActivity.class);
        startActivity(intent);
    }

    public void addProductToDB(View view) {
        //This is similiar to the register activity where we validate the values entered, and then insert them into firebase
        final String cost = etCost.getText().toString().trim();
        String category = spCategory.getSelectedItem().toString();
        final String name = etName.getText().toString().trim();

        //Validate that all details are entered
        if(TextUtils.isEmpty(cost)){
            etCost.setError("Price is Required.");
            return;
        }
        if(TextUtils.isEmpty(name)){
            etName.setError("Name is Required.");
            return;
        }
        //the first item in the spinner tells the user to choose a value, so if the position is 0  it is still on that entry
        //adapted from https://stackoverflow.com/a/42336807
        if(spCategory.getSelectedItemPosition() == 0){
            Toast.makeText(this, "Choose a Category", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add a new product with a generated id.
        //If its successful, then show a toast to notify the user and then move back to the admin home activity
        Map<String, Object> data = new HashMap<>();
        data.put("Cost", cost);
        data.put("Name", name);
        data.put("Category", category);

        db.collection("Products")
                .add(data)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(AddProductActivity.this, "Product Successfully Added!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(AddProductActivity.this,AdminHomeActivity.class);
                        startActivity(intent);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddProductActivity.this, "Failed to Add Product - " + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}