package com.example.officerewards.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.officerewards.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EditProductActivity extends AppCompatActivity {

    //declare on screen components and the firestore instance allowing us to access our firestore data
    String name, category, cost, id;
    Button btnSave, btnCancel;
    EditText etName, etCost;
    Spinner spCategory;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        btnSave = findViewById(R.id.btnSaveEditProduct);
        btnCancel = findViewById(R.id.btnCancelEditProduct);
        etName = findViewById(R.id.etEditProductName);
        etCost = findViewById(R.id.etEditProductPrice);
        spCategory = findViewById(R.id.spEditProductCategory);

        Bundle extras = getIntent().getExtras();
        //Get extras on the intent, adapted from https://stackoverflow.com/a/23059048
        if (extras != null) {
            if (extras.containsKey("PRODUCTID")) {
                id = extras.getString("PRODUCTID");
                name = extras.getString("PRODUCTNAME");
                category = extras.getString("PRODUCTCATEGORY");
                cost = extras.getString("PRODUCTCOST");
                etName.setText(name);
                etCost.setText(cost);
            }
        }

        //Adapted from https://stackoverflow.com/a/4228121/15339465
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.categories, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spCategory.setAdapter(adapter);

        //match the selected item in the spinner to the string passed in from the previous activity
        //adapted from https://stackoverflow.com/a/4228121/15339465
        if (category != null) {
            int spinnerPosition = adapter.getPosition(category);
            spCategory.setSelection(spinnerPosition);
        }
    }

    //return to previous activity
    public void cancelEditProduct(View view) {
        Intent intent = new Intent(EditProductActivity.this,ExistingProductsActivity.class);
        startActivity(intent);
    }

    //similar to the register method
    //get the details entered by the user, validate them, then update the record of the product using its ID
    //we then inform the user the product has beeen updated and take them to the previous screen
    public void saveEditProduct(View view) {
        final String cost = etCost.getText().toString().trim();
        String category = spCategory.getSelectedItem().toString();
        final String name = etName.getText().toString().trim();

        //Validate that all details are entered
        if(TextUtils.isEmpty(cost)){
            etCost.setError("Price is Required.");
            return;
        }
        if(TextUtils.isEmpty(name)){
            etName.setError("Name is Required.");
            return;
        }
        if(spCategory.getSelectedItemPosition() == 0){
            Toast.makeText(this, "Choose a Category", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> data = new HashMap<>();
        data.put("Cost", cost);
        data.put("Name", name);
        data.put("Category", category);

        db.collection("Products").document(id)
                .set(data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(EditProductActivity.this, "Product Successfully Updated!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(EditProductActivity.this,ExistingProductsActivity.class);
                        startActivity(intent);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(EditProductActivity.this, "Error - " + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}