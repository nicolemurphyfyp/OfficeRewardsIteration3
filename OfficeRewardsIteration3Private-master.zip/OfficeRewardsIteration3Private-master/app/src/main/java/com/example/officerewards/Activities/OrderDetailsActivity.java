package com.example.officerewards.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.officerewards.R;

import java.util.ArrayList;
import java.util.List;

import adapter.OrderDetailRecyclerAdapter;
import model.Product;

public class OrderDetailsActivity extends AppCompatActivity {
    //recycler code adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    List<Product> productList;
    // Recycler View object
    RecyclerView recyclerView;
    // Layout Manager
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    RecyclerView.Adapter adapter;
    // Linear Layout Manager
    LinearLayoutManager LayoutManager;
    TextView txtOrderID, txtOrderDate, txtOrderTotal;
    String cost, date, orderid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        txtOrderID = findViewById(R.id.txtOrderNumber);
        txtOrderDate = findViewById(R.id.txtOrderPlaced);
        txtOrderTotal = findViewById(R.id.txtOrderDetailTotal);

        productList = new ArrayList<Product>();

        //getting extras on the intent adapted from https://stackoverflow.com/a/31972180
        Bundle extras = getIntent().getExtras();
        //Get extras on the intent
        if (extras != null) {
            if (extras.containsKey("LIST")) {
                //passing a list of objects on an intent adapted from https://stackoverflow.com/a/31972180
                productList = (List<Product>) extras.getSerializable("LIST");
                cost = extras.getString("COST");
                date = extras.getString("DATE");
                orderid = extras.getString("ID");
                txtOrderDate.setText(date);
                txtOrderID.setText(orderid);
                txtOrderTotal.setText("Total: " + cost + " Points");
            }
        }

        //pass the list of products retrieved from the intent to the recycler, so the user can view all items that were part of the order
        adapter = new OrderDetailRecyclerAdapter(productList, OrderDetailsActivity.this);
        LayoutManager = new LinearLayoutManager(OrderDetailsActivity.this,LinearLayoutManager.VERTICAL,false);
        recyclerView = findViewById(R.id.rvOrderDetails);
        recyclerView.setLayoutManager(LayoutManager);
        recyclerView.setAdapter(adapter);
    }

    public void goHome (View view) {
        Intent intent = new Intent(OrderDetailsActivity.this,HomeActivity.class);
        startActivity(intent);
    }
}