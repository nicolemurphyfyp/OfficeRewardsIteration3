package model;

public class OrderItem {
    private String name;
    private String category;
    private String price;
    private String id;
    private int quantity;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public OrderItem() {
    }

    public OrderItem(String name, String category, String price, String id, int quantity) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.id = id;
        this.quantity = quantity;
    }
}
