package model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

public class Order implements Comparable<Order> {
    private String id;
    private String date;
    private String cost;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }
    //implementing comparable, adding the getconvertedDate function and overriding compareTo allows for sorting Orders by date
    //adapted from https://www.baeldung.com/java-sort-list-by-date
    public Date getconvertedDate() throws ParseException {
        //converts from string to date
        DateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Date date = format.parse(getDate());
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public Order() {
    }

    public Order(String id, String date, String cost) {
        this.id = id;
        this.date = date;
        this.cost = cost;
    }

    @Override
    public int compareTo(Order order) {
        try {
            return getconvertedDate().compareTo(order.getconvertedDate());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
