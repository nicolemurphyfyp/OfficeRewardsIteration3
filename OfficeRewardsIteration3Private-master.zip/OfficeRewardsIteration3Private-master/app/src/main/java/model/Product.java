package model;

import java.io.Serializable;

//implement serializable so that we can pass a list of products on an intent
//adapted from https://stackoverflow.com/a/31972180
public class Product implements Serializable {
    private String name;
    private String category;
    private String price;
    private String id;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getID() {
        return id;
    }

    public void setID (String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Product(String name, String category, String price) {
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public Product(String name, String category, String price, String id) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.id = id;
    }

    public Product() {
    }
}
