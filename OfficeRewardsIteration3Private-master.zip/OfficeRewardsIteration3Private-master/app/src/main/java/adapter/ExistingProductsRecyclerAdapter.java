package adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.officerewards.Activities.EditProductActivity;
import com.example.officerewards.Activities.HomeActivity;
import com.example.officerewards.Activities.LoginActivity;
import com.example.officerewards.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DecimalFormat;
import java.util.List;

import model.Product;

//Recycler Custom Adapter adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
public class ExistingProductsRecyclerAdapter extends RecyclerView.Adapter<ExistingProductsRecyclerAdapter.MyViewHolder> {

    List<Product> productList;
    Context context;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    public ExistingProductsRecyclerAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtProductName, txtProductCost, txtProductCategory;
        Button btnEditProduct, btnDeleteProduct;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtProductName = itemView.findViewById(R.id.txtProductViewName);
            txtProductCost = itemView.findViewById(R.id.txtProductViewCost);
            txtProductCategory = itemView.findViewById(R.id.txtProductViewCategory);
            btnEditProduct = itemView.findViewById(R.id.btnEditProduct);
            btnDeleteProduct = itemView.findViewById(R.id.btnDeleteProduct);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewproduct,parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.txtProductName.setText(productList.get(position).getName());
        holder.txtProductCost.setText("Price: " + String.valueOf(productList.get(position).getPrice()));
        holder.txtProductCategory.setText(productList.get(position).getCategory());
        holder.btnEditProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EditProductActivity.class);
                //Passing extra on the intent to pass data to the edit product activity.
                //adapted from https://stackoverflow.com/a/23059048
                intent.putExtra("PRODUCTID", productList.get(position).getID());
                intent.putExtra("PRODUCTNAME", productList.get(position).getName());
                intent.putExtra("PRODUCTCOST", productList.get(position).getPrice());
                intent.putExtra("PRODUCTCATEGORY", productList.get(position).getCategory());
                context.startActivity(intent);
            }
        });

        holder.btnDeleteProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Products").document(productList.get(position).getID())
                        .delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(context, "Product Deleted", Toast.LENGTH_SHORT).show();
                                //Removing from the list passed to the recycler view, adapted from https://stackoverflow.com/a/38167883
                                productList.remove(position);
                                notifyItemRemoved(position);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(context, "Error - " + e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

}
