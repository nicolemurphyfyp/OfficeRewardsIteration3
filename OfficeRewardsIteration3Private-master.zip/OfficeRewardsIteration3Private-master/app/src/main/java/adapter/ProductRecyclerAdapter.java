package adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.officerewards.Activities.MapsActivityCurrentPlace;
import com.example.officerewards.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Document;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Product;

public class ProductRecyclerAdapter extends RecyclerView.Adapter<ProductRecyclerAdapter.MyViewHolder>{

    List<Product> productList;
    Context context;
    String userID;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth auth;

    public ProductRecyclerAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imProduct;
        TextView txtProductName;
        Button btnAddtoBasket;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imProduct = itemView.findViewById(R.id.imProductImage);
            txtProductName = itemView.findViewById(R.id.txtProductName);
            btnAddtoBasket = itemView.findViewById(R.id.btnAddtoBasket);

        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product,parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        //Getting image from drawable folder adapted from https://developer.android.com/guide/topics/resources/drawable-resource#java
        //image used is from https://www.flaticon.com/free-icon/gift-voucher_2575222
        Resources res = context.getResources();
        Drawable drawable = ResourcesCompat.getDrawable(res, R.drawable.giftvoucher, null);
        auth = FirebaseAuth.getInstance();
        userID = auth.getCurrentUser().getUid();
        CollectionReference basketsRef = db.collection("Baskets").document(userID).collection("cartItems");


        //using the glide framework to place the image we got above into the imageview
        //code adapted from https://bumptech.github.io/glide/doc/getting-started.html and https://www.youtube.com/watch?v=FFCpjZkqfb0
        Glide.with(this.context).load(drawable).into(holder.imProduct);
        holder.txtProductName.setText(productList.get(position).getName());
        //When the user clicks add to basket, first we check if the item is already in the basket
        //if it is not already in the basket, then we create a hashmap with the product details and insert it into firebase,
        //specifically into the cartitems subcollection of the basket collection. So the path is Baskets - USERID - cartItems - PRODUCTID
        //structure for basket data in firebase adapted from https://stackoverflow.com/a/71227953
        holder.btnAddtoBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("NEWCHECKS", "basket add clicked");

                            basketsRef.whereEqualTo("UserID", userID).whereEqualTo("ProductID", productList.get(position).getID())
                                            .get()
                                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                            if (task.isSuccessful()) {
                                                                Log.d("NEWCHECKS", "task successful");
                                                                QuerySnapshot documents = task.getResult();
                                                                if (documents.size() > 0) {
                                                                    Log.d("NEWCHECKS", "already in basket");
                                                                    Toast.makeText(context, "Already in Basket!", Toast.LENGTH_SHORT).show();
                                                                }
                                                                else {
                                                                    Log.d("NEWCHECKS", "not in basket");
                                                                    Map<String, Object> data = new HashMap<>();
                                                                    data.put("ProductID", productList.get(position).getID());
                                                                    data.put("UserID", userID);
                                                                    data.put("ProductName", productList.get(position).getName());
                                                                    data.put("Cost", productList.get(position).getPrice());
                                                                    data.put("Category", productList.get(position).getCategory());
                                                                    data.put("Quantity", 1);
                                                                    Log.d("NEWCHECKS", "price " + productList.get(position).getPrice());

                                                                    db.collection("Baskets").document(userID).collection("cartItems").document(productList.get(position).getID())
                                                                            .set(data)
                                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                @Override
                                                                                public void onSuccess(Void unused) {
                                                                                    Toast.makeText(context, "Added to Basket!", Toast.LENGTH_SHORT).show();
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        }
                                                    });
            }
        });


    }

    @Override
    public int getItemCount() {
        return productList.size();
    }
}
