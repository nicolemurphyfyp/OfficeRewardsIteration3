package adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.officerewards.Activities.EditProductActivity;
import com.example.officerewards.Activities.OrderDetailsActivity;
import com.example.officerewards.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import model.Product;

//Recycler Custom Adapter adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
public class OrderDetailRecyclerAdapter extends RecyclerView.Adapter<OrderDetailRecyclerAdapter.MyViewHolder>{
    List<Product> productList;
    Context context;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    public OrderDetailRecyclerAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtProductName, txtProductCost, txtProductCategory;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtProductName = itemView.findViewById(R.id.txtOrderDetailName);
            txtProductCost = itemView.findViewById(R.id.txtOrderDetailCost);
            txtProductCategory = itemView.findViewById(R.id.txtOrderDetailCategory);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderdetailitem,parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.txtProductName.setText(productList.get(position).getName());
        holder.txtProductCost.setText("Price: " + productList.get(position).getPrice());
        holder.txtProductCategory.setText(productList.get(position).getCategory());
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }
}
