package adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.officerewards.Activities.BasketActivity;
import com.example.officerewards.Activities.EditProductActivity;
import com.example.officerewards.Activities.OrderDetailsActivity;
import com.example.officerewards.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import model.Order;
import model.OrderItem;
import model.Product;

public class OrderListRecyclerAdapter extends RecyclerView.Adapter<OrderListRecyclerAdapter.MyViewHolder>{
    List<Order> orderList;
    Context context;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth auth;
    String userID;

    public OrderListRecyclerAdapter(List<Order> orderList, Context context) {
        this.orderList = orderList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtOrderDate, txtOrderCost;
        Button btnViewOrder;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtOrderCost = itemView.findViewById(R.id.txtOrderCost);
            txtOrderDate = itemView.findViewById(R.id.txtOrderDate);
            btnViewOrder = itemView.findViewById(R.id.btnViewOrder);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderitem,parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        auth = FirebaseAuth.getInstance();
        userID = auth.getCurrentUser().getUid();
        List<Product> productList = new ArrayList<Product>();

        holder.txtOrderCost.setText(orderList.get(position).getCost() + " Points");
        holder.txtOrderDate.setText(orderList.get(position).getDate());

        //Pass the ID of the order clicked on to firebase, and get each item from the order, then pass on that list of items and order details to the order details screen
        holder.btnViewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Orders").document(orderList.get(position).getId()).collection("orderItems")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        String name = (String) document.getData().get("name");
                                        String price = (String) document.getData().get("price");
                                        String id = (String) document.getData().get("id");
                                        String category = (String) document.getData().get("category");
                                        Product product = new Product(name, category, price, id);
                                        productList.add(product);

                                        if (productList.size() == task.getResult().size()) {
                                            //passing extras on the intent adapted from https://stackoverflow.com/a/23059048
                                            Intent intent = new Intent(context, OrderDetailsActivity.class);
                                            //passing list of objects on an intent adapted from https://stackoverflow.com/a/31972180
                                            intent.putExtra("LIST", (Serializable) productList);
                                            intent.putExtra("DATE", orderList.get(position).getDate());
                                            intent.putExtra("COST", orderList.get(position).getCost());
                                            intent.putExtra("ID", orderList.get(position).getId());
                                            context.startActivity(intent);
                                        }
                                    }
                                }
                            }
                        });


            }
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }
}
