package adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.officerewards.Activities.BasketActivity;
import com.example.officerewards.Activities.EditProductActivity;
import com.example.officerewards.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import model.OrderItem;
import model.Product;

//Recycler Custom Adapter adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
public class BasketItemRecyclerAdapter extends RecyclerView.Adapter<BasketItemRecyclerAdapter.MyViewHolder>{
    List<OrderItem> orderItemList;
    Context context;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth auth;
    String userID;

    public BasketItemRecyclerAdapter(List<OrderItem> orderItemList, Context context) {
        this.orderItemList = orderItemList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtProductName, txtProductCost;
        Button btnDeleteProduct;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtProductName = itemView.findViewById(R.id.txtProductBasketName);
            txtProductCost = itemView.findViewById(R.id.txtProductBasketCost);
            btnDeleteProduct = itemView.findViewById(R.id.btnRemoveFromBasket);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.basketitem,parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        auth = FirebaseAuth.getInstance();
        userID = auth.getCurrentUser().getUid();

        holder.txtProductName.setText(orderItemList.get(position).getName());
        holder.txtProductCost.setText("Price: " + String.valueOf(orderItemList.get(position).getPrice()) + " Points");


        holder.btnDeleteProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Baskets").document(userID).collection("cartItems").document(orderItemList.get(position).getId())
                        .delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(context, "Removed from Basket", Toast.LENGTH_SHORT).show();
                                //Removing from the list passed to the recycler view, adapted from https://stackoverflow.com/a/38167883
                                orderItemList.remove(position);
                                notifyItemRemoved(position);
                                //call the retrieve data method in BasketActivity when we delete a record, adapted from https://stackoverflow.com/a/12142492
                                if (context instanceof BasketActivity) {
                                    ((BasketActivity)context).retrieveData();
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(context, "Error - " + e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }


    @Override
    public int getItemCount() {
        return orderItemList.size();
    }


}
